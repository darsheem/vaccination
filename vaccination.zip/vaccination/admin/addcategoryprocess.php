<?php
	session_start();
	//var_dump($_POST);
	require 'dbconnect.php';
	if(!isset($_SESSION['a_fn']))
    {
        header("location:index.php");
    }
	if(!isset($_POST['btn_sb']))
	{
		header("location:addcategory.php");
	}

	$v_name=$_POST['v_name'];
	$v_dose=$_POST['v_dose'];
	$v_dur=$_POST['v_dur'];
	$v_price=$_POST['v_price'];
	$isactive=1;

	$qry="INSERT INTO vaccine(v_name,v_dose,v_duration,v_price,v_avail) VALUES('".$v_name."','".$v_dose."','".$v_dur."','".$v_price."','".$isactive."')";
	$rs=mysqli_query($conn,$qry);
	if ($rs) 
	{
		header("location:viewcategory.php");
		//echo "Category $catname successfully added";	
	}
	else
	{
		header("location:addcategory.php?err=Error in adding vaccine");
		//echo "Error";
	}
?>	