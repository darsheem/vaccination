<?php
	session_start();
	//var_dump($_POST);
	require 'dbconnect.php';

	if(!isset($_POST['btn_sb']))
	{
		header("location:addcity.php");
	}

	$cityname=$_POST['city_name'];
	$state_id=$_POST['state_id'];
	$isactive=1;
	
	if(ctype_alpha($cityname))
	{
		$qry="INSERT INTO city_tbl(city_name,state_id,isactive) VALUES('".$cityname."',$state_id,$isactive)";
		$rs=mysqli_query($conn,$qry);
		if ($rs) 
		{
			header("location:viewcity.php");
			//echo "City $cityname successfully added";	
		}
		else
		{
			header("location:addcity.php?err=Error in adding city");
			//echo "Error";
		}
	}
	else
	{
		header("location:addcity.php?err=Only alphabets are allowed");
		//echo "Not A Character";
		exit();
	}
?>	