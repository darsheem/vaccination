<?php
    require 'dbconnect.php';
    session_start();
    $a_id=$_SESSION['a_id'];
    if(!isset($_SESSION['a_fn']))
    {
        header("location:index.php");
    }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>E-CoVaccine - Admin Dashboard</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="dashboard.php">E-CoVaccine</a>
            </div>

            <div class="notifications-wrapper">
            <ul class="nav text-right">
              
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user-plus"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                      
                        <li class="divider"></li>
                        <li><a href="profile.php"><i class="fa fa-sign-out"></i>Profile</a>
                        </li>
                        <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                        </li>
                    </ul>
                </li>
            </ul>
            </div>
        </nav>
        <!-- /. NAV TOP  -->
        
        <nav  class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <?php
                            $qry="SELECT * FROM user WHERE uid=$a_id";
                            $rs=mysqli_query($conn,$qry);
                            if(mysqli_num_rows($rs)>0)
                            {
                                while($row=mysqli_fetch_assoc($rs))
                                {      
                        ?>
                        <div class="user-img-div">
                            <!-- <img src="<?php echo $row['profile_pic']?>" class="img-circle" /> -->
                            <img src="images/u5.jpg" class="img-circle">
                        </div>
                        <?php 
                                }
                            }
                        ?>
                    </li>
                    
                    <li>
                        <a href="dashboard.php"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage Vaccine <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addcategory.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Vaccine</a>
                            </li>
                            <li>
                                <a href="viewcategory.php"><i class="glyphicon glyphicon-eye-open "></i>View Vaccine</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a class="active-menu" href="#"><i class="fa fa-caret-down "></i>Manage Center <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addproduct.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Center</a>
                            </li>
                            <li>
                                <a href="viewproduct.php"><i class="glyphicon glyphicon-eye-open"></i>View Center</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage State <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addstate.php"><i class="glyphicon glyphicon-plus-sign "></i>Add state</a>
                            </li>
                            <li>
                                <a href="viewst.php"><i class="glyphicon glyphicon-eye-open "></i>View state</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage City <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addcity.php"><i class="glyphicon glyphicon-plus-sign "></i>Add city</a>
                            </li>
                            <li>
                                <a href="viewcity.php"><i class="glyphicon glyphicon-eye-open"></i>View city</a>
                            </li>
                        </ul>
                    </li>
        
                    <li>
                        <a href="#"><i class="glyphicon glyphicon-question-sign "></i>Manage Security Question <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addseq.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Security Question</a>
                            </li>
                            <li>
                                <a href="viewseq.php"><i class="glyphicon glyphicon-eye-open "></i>View Security Question</a>
                            </li>
                        </ul>
                    </li>
                    
                    
                    <!-- <li>
                        <a href="viewfdbk.php"><i class="fa fa-pencil "></i>View Feedback</a>
                    </li>
                    <li>
                        <a href="viewcomplain.php"><i class="fa fa-envelope "></i>View Complain</a>
                    </li>
                    <li>
                        <a href="viewinquiry.php"><i class="glyphicon glyphicon-question-sign"></i>View Inquiry</a>
                    </li> -->
                    <li>
                        <a href="viewusr.php"><i class="fa fa-user "></i>View User</a>
                    </li>
                
                    <li>
                        <a href="viewappoint.php"><i class="fa fa-pencil"></i>View Appointments</a>
                    </li>
                </ul>
            </div>
        </nav>   
        <!-- PRODUCT TABLE DATA -->
        <?php
            $qry="SELECT * FROM state_tbl where isactive=1";
            $rs=mysqli_query($conn,$qry);

            $qry1="SELECT * FROM city_tbl where isactive=1";
            $rs1=mysqli_query($conn,$qry1);  
        ?>
        <!-- /. SIDEBAR MENU (navbar-side) -->

        <div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Add Centers for Vaccine</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8 col-lg-offset-2">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               
                            </div>
                        <div class="panel-body">
                            <form id="demo-form" class="form-horizontal" method="post" action="addproductprocess.php">
                              <div class="form-group">
                                
                                <input type="hidden" class="form-control" name="aid" value="<?php echo $aid;?>">
                                
                                <label for="exampleInputEmail1">Center name</label>
                                <input data-parsley-maxlength="50" type="text" class="form-control" id="exampleInputEmail1" name="c_name" placeholder="Enter center name" required/><br>

                                <label for="exampleInputEmail1">Center State </label>
                                    <select name="sn" class="form-control state_name" required>
                                        <option value="" selected disabled>--Select State--</option>
                                        <?php 
                                            if (mysqli_num_rows($rs)>0) 
                                            {
                                                while($row=mysqli_fetch_assoc($rs))
                                                {
                                        ?>
                                        
                                        <option value="<?php echo $row['id']; ?>"><?php echo $row['state_name']; ?></option>
                                        <?php           
                                                }   
                                            } 
                                        ?>
                                    </select><br>

                                <label for="exampleInputEmail1">Center City </label>
                                    <select name="cn" class="form-control city_name" required>
                                        <option value="" selected disabled>--Select City--</option>
                                    </select><br>

                                <label for="exampleInputEmail1">Center Area</label>
                                <input data-parsley-maxlength="50" type="text" class="form-control" id="exampleInputEmail1" name="c_area" placeholder="Enter center area" required/><br>

                                <label> Center Address </label>
                                <textarea data-parsley-maxlength="300" rows="3" cols="70" class="form-control" name="c_addr" required> </textarea> <br>

                                <label> Center Head Name </label>
                                <input data-parsley-maxlength="50" type="text" class="form-control" id="exampleInputEmail1" name="c_head_name" placeholder="Enter center head name" required/><br>

                                <label> Center Head Email </label>
                                <input type="email" class="form-control" id="exampleInputEmail1" name="c_head_email" placeholder="Enter center head email" required/><br>
                              </div>
                             
                            <input type="submit" class="btn btn-primary" name="btn_sb" value="Add Center">

                            </form>
                        </div>
                        <?php 
                            if(isset($_GET['err']))
                            {
                                $msg=$_GET['err'];
                            }
                            else
                            {
                                $msg="";
                            }
                        ?>
                        <h5 style="color:red"><?php echo $msg?> </h5>  
                        </div>
                    </div>
                </div>
            </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <footer >
        &copy;<a href="http://www.designbootstrap.com/" target="_blank">E-CoVaccine</a>
    </footer>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    <!--VALIDATION SCRIPT -->
    <script src="assets/js/parsley.min.js"></script>
    <script>
            $('#demo-form').parsley();
    </script>
    <script>
        $("select.state_name").change(function(){
            var select_id = $(".state_name option:selected").val();
            //alert(select_id);
            var qrystrng = 'id='+select_id;
            $.ajax({
                type:"POST",
                url: "search_city.php",
                data:qrystrng,
                dataType:"html",
                success: function(response){
                    $(".city_name").html(response);
                }
            })
        });
    </script>
</body>
</html>
