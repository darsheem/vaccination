<?php
	session_start();
	//var_dump($_POST);
	require 'dbconnect.php';

	if(!isset($_POST['btn_sb']))
	{
		header("location:addproduct.php");
	}

	$admin_id=$_POST['aid'];
	$c_name=$_POST['c_name'];
	$state_name=$_POST['sn'];
	$city_name=$_POST['cn'];
	$c_area=$_POST['c_area'];
	$c_addr=$_POST['c_addr'];
	$c_head_name=$_POST['c_head_name'];
	$c_head_email=$_POST['c_head_email'];
	$c_head_pswd = "EVaccine21";
	$isactive=1;	

	$qry="INSERT INTO `center` (`c_name`, `c_address`, `c_area`, `c_city`, `c_state`, `c_head_name`, `c_head_email`, `c_head_password`, `isactive`) VALUES ('$c_name', '$c_addr', '$c_area', '$city_name', '$state_name', '$c_head_name', '$c_head_email', '$c_head_pswd', '$isactive')";

	$rs=mysqli_query($conn,$qry);
	//echo $rs;

	if ($rs) 
	{
		header("location:viewproduct.php");
		//echo "Product $pr_name successfully added";	
	}
	else
	{
		header("location:addproduct.php?err=Error in adding vaccination center");
		//echo "Error";
	}	
?>