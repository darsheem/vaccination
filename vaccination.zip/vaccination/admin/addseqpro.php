<?php
	require 'dbconnect.php';
	//var_dump($_POST);
	$question = $_POST['sec_que'];
	$isactive = 1;
	
	$qry = "INSERT INTO `security`(`s_question`,`isactive`)VALUES('".$question."','".$isactive."')";
	$rs = mysqli_query($conn,$qry);
	if($rs)
	{
		header("location:viewseq.php");
		//echo "question inserted";
	}
	else
	{
		header("location:addseq.php?err=Error in adding security question");
		//echo mysqli_error();
	}
?>