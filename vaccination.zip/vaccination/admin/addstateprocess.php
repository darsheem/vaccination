<?php
	session_start();
	//var_dump($_POST);
	require 'dbconnect.php';

	if(!isset($_POST['btn_sb']))
	{
		header("location:addstate.php");
	}

	$statename=$_POST['state_name'];
	$isactive=1;
	if(ctype_alpha($statename))
	{
		$qry="INSERT INTO state_tbl(state_name,isactive) VALUES('".$statename."','".$isactive."')";
		$rs=mysqli_query($conn,$qry);
		if ($rs) 
		{
			header("location:viewst.php");
			//echo "State $statename successfully added";	
		}
		else
		{
			header("location:addstate.php?err=Error in adding state");
			//echo "Error";
		}
	}
	else
	{
		header("location:addstate.php?err=Only alphabets are allowed");
		//exit();
	}
?>	