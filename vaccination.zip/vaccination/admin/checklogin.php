<?php

  	require 'dbconnect.php';
  	session_start();
  	//var_dump($_POST);
	if (!isset($_POST["btn_sb"]))
	{
	 	header("location:index.php");
	 	exit();
	}

	$us=$_POST['un'];
	$ps=$_POST['txt_pass'];

	$qry= "SELECT * FROM user WHERE u_email='".$us."' AND u_pass='".$ps."' AND u_type=1";
	//echo $qry."<br><br>";

	$rs=mysqli_query($conn,$qry);
	if (mysqli_num_rows($rs)>0) 
	{
		$row=mysqli_fetch_assoc($rs);
		$_SESSION['a_id']=$row['uid'];
		$_SESSION['a_fn']=$row['u_name'];

		if (isset($_POST['remember'])) 
		{
			setcookie("a_user",$us,time()+(86400 * 30), "/");
			setcookie("a_pass",$ps,time()+(86400 * 30), "/");
		}

		//echo "Hi";
		header("location:dashboard.php");
		exit();
	}	

	//echo "Invalid Login";
	header("location:index.php?err=Invalid username or password");
?>