﻿<!-- CHECKING IF LOGIN IS DONE OR NOT  -->
<?php
    require 'dbconnect.php';
    session_start();
    //var_dump($_SSESSION);
    if(!isset($_SESSION['a_fn']))
    {
        header("location:index.php");
    }
    $id=$_SESSION['a_id'];
    $user=$_SESSION["a_fn"];

    $qry1 = "SELECT * FROM user WHERE u_type=2";
    $rs1=mysqli_query($conn,$qry1);
    $u=mysqli_num_rows($rs1);

    $qry3 = "SELECT * FROM center;";
    $rs3=mysqli_query($conn,$qry3);
    $c=mysqli_num_rows($rs3);

    $qry4 = "SELECT * FROM vaccine";
    $rs4=mysqli_query($conn,$qry4);
    $p=mysqli_num_rows($rs4);

    $qry5 = "SELECT * FROM center";
    $rs5=mysqli_query($conn,$qry5);
    $o=mysqli_num_rows($rs5);

    $qry7 = "SELECT * FROM vaccine_booked";
    $rs7=mysqli_query($conn,$qry7);
    $f=mysqli_num_rows($rs7);

    $qry8 = "SELECT * FROM state_tbl";
    $rs8=mysqli_query($conn,$qry8);
    $com=mysqli_num_rows($rs8);

    $qry9 = "SELECT * FROM city_tbl";
    $rs9=mysqli_query($conn,$qry9);
    $i=mysqli_num_rows($rs9);

    $qry11 = "SELECT * FROM security";
    $rs11=mysqli_query($conn,$qry11);
    $s=mysqli_num_rows($rs11);

    // $qry12 = "SELECT * FROM state_tbl";
    // $rs12=mysqli_query($conn,$qry12);
    // $st=mysqli_num_rows($rs12);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>E-CoVaccine - Admin Dashboard</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- ANIMATION CSS-->
    <link rel="stylesheet" href="assets/css/animate.css"> 
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="dashboard.php">E-CoVaccine</a>
            </div>

            <div class="notifications-wrapper">
                <ul class="nav text-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user-plus"></i>  <i class="fa fa-caret-down"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user ">
                            <li><a href="profile.php"><i class="fa fa-sign-out"></i>Profile</a> </li>
                            <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- /. NAV TOP  -->

        <nav  class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <?php
                            $qry="SELECT * FROM user WHERE uid=$id";
                            $rs=mysqli_query($conn,$qry);
                            if(mysqli_num_rows($rs)>0)
                            {
                                while($row=mysqli_fetch_assoc($rs))
                                {      
                        ?>
                        <div class="user-img-div">
                            <img src="images/u5.jpg" class="img-circle">
                        </div>
                        <?php 
                                }
                            }
                        ?>
                    </li>
                    
                    <li>
                        <a class="active-menu"  href="dashboard.php"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage Vaccine <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addcategory.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Vaccine</a>
                            </li>
                            <li>
                                <a href="viewcategory.php"><i class="glyphicon glyphicon-eye-open "></i>View Vaccine</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-caret-down "></i>Manage Center <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addproduct.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Center</a>
                            </li>
                            <li>
                                <a href="viewproduct.php"><i class="glyphicon glyphicon-eye-open"></i>View Center</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage State <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addstate.php"><i class="glyphicon glyphicon-plus-sign "></i>Add state</a>
                            </li>
                            <li>
                                <a href="viewst.php"><i class="glyphicon glyphicon-eye-open "></i>View state</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage City <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addcity.php"><i class="glyphicon glyphicon-plus-sign "></i>Add city</a>
                            </li>
                            <li>
                                <a href="viewcity.php"><i class="glyphicon glyphicon-eye-open"></i>View city</a>
                            </li>
                        </ul>
                    </li>
        
                    <li>
                        <a href="#"><i class="glyphicon glyphicon-question-sign "></i>Manage Security Question <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addseq.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Security Question</a>
                            </li>
                            <li>
                                <a href="viewseq.php"><i class="glyphicon glyphicon-eye-open "></i>View Security Question</a>
                            </li>
                        </ul>
                    </li>
                    
                    
                    <!-- <li>
                        <a href="viewfdbk.php"><i class="fa fa-pencil "></i>View Feedback</a>
                    </li>
                    <li>
                        <a href="viewcomplain.php"><i class="fa fa-envelope "></i>View Complain</a>
                    </li>
                    <li>
                        <a href="viewinquiry.php"><i class="glyphicon glyphicon-question-sign"></i>View Inquiry</a>
                    </li> -->
                    <li>
                        <a href="viewusr.php"><i class="fa fa-user "></i>View User</a>
                    </li>
                
                    <li>
                        <a href="viewappoint.php"><i class="fa fa-pencil"></i>View Appointments</a>
                    </li>
                </ul>
            </div>
        </nav>          
        <!-- /. SIDEBAR MENU (navbar-side) -->

        <div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12 animated slideInRight">
                        <h1 class="page-head-line">Dashboard-<?php echo $user; ?></h1>
                    </div>
                </div>

               
            <div class="row">
                <div class=" col-md-3 col-sm-3">
                    <div class="style-box-one Style-one-clr-one">
                        <a href="viewusr.php">
                            <h3> USERS</h3>
                            <h4><?php echo $u ?></h4>
                        </a>
                    </div>
                </div>

                <div class=" col-md-3 col-sm-3">
                    <div class="style-box-one Style-one-clr-two">
                        <a href="viewcategory.php">
                            <h3> CENTER HEADS</h3>
                            <h4><?php echo $c ?></h4>
                        </a>
                    </div>
                </div>   

                <div class=" col-md-3 col-sm-3">
                    <div class="style-box-one Style-one-clr-three">
                        <a href="viewcategory.php">
                            <h3> VACCINES</h3>
                            <h4><?php echo $p ?></h4>
                        </a>
                    </div>
                </div> 

                <div class=" col-md-3 col-sm-3">
                    <div class="style-box-one Style-one-clr-four">
                        <a href="viewcategory.php">
                            <h3> CENTERS</h3>
                            <h4><?php echo $o ?></h4>
                        </a>
                    </div>
                </div>    
            </div>

            <div class="row">
                <div class=" col-md-3 col-sm-3">
                    <div class="style-box-one Style-one-clr-one">
                        <a href="viewappoint.php">
                            <h3> BOOKINGS</h3>
                            <h4><?php echo $f ?></h4>
                        </a>
                    </div>
                </div>   

                <div class=" col-md-3 col-sm-3">
                    <div class="style-box-one Style-one-clr-two">
                        <a href="viewcity.php">
                            <h3> CITIES</h3>
                            <h4><?php echo $i ?></h4>
                        </a>
                    </div>
                </div>
                
                <div class=" col-md-3 col-sm-3">
                    <div class="style-box-one Style-one-clr-three">
                        <a href="viewst.php">
                            <h3> STATES</h3>
                            <h4><?php echo $com ?></h4>
                        </a>
                    </div>
                </div>

                <div class=" col-md-3 col-sm-3">
                    <div class="style-box-one Style-one-clr-four">
                        <a href="viewseq.php">
                            <h3> QUESTIONS</h3>
                            <h4><?php echo $s ?></h4>
                        </a>
                    </div>
                </div> 
            </div>  

            <div class="row"> 
            </div> 
            </div>
        </div>     
            <!-- /. PAGE INNER  -->
    </div>
        <!-- /. PAGE WRAPPER  -->
    <!-- /. WRAPPER  -->
    <footer >
        &copy;<a href="http://www.designbootstrap.com/" target="_blank">E-CoVaccine</a>
    </footer>
    <!-- /. FOOTER  -->

    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
