<?php
	require 'dbconnect.php';
	//var_dump($_GET);
	$id=$_GET['id'];
	//echo $id;

	$qry1="UPDATE vaccine SET v_avail=2 WHERE v_id=$id";
	//echo $qry1;

	$rs1=mysqli_query($conn,$qry1);
	if($rs1)
	{
		//echo "Category deleted successfully";
		header("location: viewcategory.php");
		exit();
	}
	else
	{
		echo "Error in deletion of category";
	}
?>