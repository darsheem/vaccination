<?php
	require 'dbconnect.php';
	//var_dump($_GET);
	session_start();
	if(!isset($_SESSION['a_fn']))
    {
        header("location:index.php");
    }
	$id=$_GET['id'];
	//echo $id;

	$qry1="UPDATE center SET isactive=2 WHERE c_id=$id";
	//echo $qry1;
	$rs1=mysqli_query($conn,$qry1);
	if($rs1)
	{
		//echo "Product Deleted";
		header("location: viewproduct.php");
		exit();
	}
	else
	{
		echo "Error in deletion";
	}
?>