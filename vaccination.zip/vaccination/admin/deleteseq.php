<?php
	require 'dbconnect.php';
	///var_dump($_GET);
	session_start();
	if(!isset($_SESSION['a_fn']))
    {
        header("location:index.php");
    }
	$id=$_GET['id'];
	//echo $id;

	$qry1="UPDATE security SET isactive=2 WHERE s_id=$id";
	//echo $qry1;
	$rs1=mysqli_query($conn,$qry1);
	if($rs1)
	{
		//echo "Security question Deleted successfully";
		header("location: viewseq.php");
		exit();
	}
	else
	{
		echo "Error in deletion of security question";
	}
?>