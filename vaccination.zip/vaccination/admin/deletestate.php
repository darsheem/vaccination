<?php
	require 'dbconnect.php';
	//var_dump($_GET);
	session_start();
	if(!isset($_SESSION['a_fn']))
    {
        header("location:index.php");
    }
	$id=$_GET['id'];
	//echo $id;

	$qry1="UPDATE state_tbl SET isactive=2 WHERE id=$id";
	//echo $qry1;
	
	$rs1=mysqli_query($conn,$qry1);
	if($rs1)
	{
		//echo "State Deleted successfully";
		header("location: viewst.php");
		exit();
	}
	else
	{
		echo "Error in deletion of state";
	}
?>