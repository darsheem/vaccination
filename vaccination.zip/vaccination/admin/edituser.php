<?php 
    require 'dbconnect.php';
    session_start();
    $a_id=$_SESSION['a_id'];
    if(!isset($_SESSION['a_fn']))
    {
        header("location:index.php");
    }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Crafts Corner - Edit User</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="dashboard.php">Crafts Corner </a>
            </div>

            <div class="notifications-wrapper">
                <ul class="nav text-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user-plus"></i>  <i class="fa fa-caret-down"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li class="divider"></li>
                            <li><a href="profile.php"><i class="fa fa-sign-out"></i>Profile</a> </li>
                            <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- /. NAV TOP  -->

        <nav  class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <?php
                            $qry="SELECT * FROM user_tbl WHERE id=$a_id";
                            $rs=mysqli_query($conn,$qry);
                            if(mysqli_num_rows($rs)>0)
                            {
                                while($row=mysqli_fetch_assoc($rs))
                                {      
                        ?>
                        <div class="user-img-div">
                            <img src="<?php echo $row['profile_pic']?>" class="img-circle" />
                        </div>
                        <?php 
                                }
                            }
                        ?>
                    </li>
                    
                    <li>
                        <a href="dashboard.php"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage Category <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addcategory.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Category</a>
                            </li>
                            <li>
                                <a href="viewcategory.php"><i class="fa fa-bullhorn "></i>View Category</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage Product <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addproduct.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Product</a>
                            </li>
                            <li>
                                <a href="viewproduct.php"><i class="fa fa-bullhorn "></i>View Product</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage State <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addstate.php"><i class="glyphicon glyphicon-plus-sign "></i>Add state</a>
                            </li>
                            <li>
                                <a href="viewst.php"><i class="fa fa-bullhorn "></i>View state</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage City <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addcity.php"><i class="glyphicon glyphicon-plus-sign "></i>Add city</a>
                            </li>
                            <li>
                                <a href="viewcity.php"><i class="fa fa-bullhorn "></i>View city</a>
                            </li>
                        </ul>
                    </li>
        
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage Security Question <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addseq.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Security Question</a>
                            </li>
                            <li>
                                <a href="viewseq.php"><i class="fa fa-bullhorn "></i>View Security Question</a>
                            </li>
                        </ul>
                    </li>
                    

                    <li>
                        <a href="viewfdbk.php"><i class="fa fa-dashcube "></i>View Feedback</a>
                    </li>
                    <li>
                        <a href="viewcomplain.php"><i class="fa fa-dashcube "></i>View Complain</a>
                    </li>
                    <li>
                        <a href="viewinquiry.php"><i class="fa fa-dashcube "></i>View Inquiry</a>
                    </li>
                    <li>
                        <a href="viewusr.php" class="active-menu"><i class="fa fa-dashcube "></i>View User</a>
                    </li>
                    <li>
                        <a href="viewseller.php"><i class="fa fa-dashcube "></i>View Seller</a>
                    </li>
                </ul>
            </div>
        </nav>
        <!--PHP CODE TO GET DATA FROM USER_TBL -->
        <?php
			$id=$_GET['id'];
			//echo $id;
			$qry="SELECT * FROM user_tbl WHERE id=$id";
			$rs=mysqli_query($conn,$qry);
			$row=mysqli_fetch_assoc($rs);
		?>
		<!-- /. SIDEBAR MENU (navbar-side) -->
		<div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit User Info</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8 col-lg-offset-2">
                        <div class="panel panel-default">
                            <div class="panel-heading"> <h4><b>Edit User Details </b> </h4>
                            </div>
                        <div class="panel-body">
                            <form id="demo-form" class="form-horizontal" method="post" action="updatedata.php" enctype="multipart/form-data">
                            <div class="form-group">

							<input type="hidden" name="txt_id" value="<?php echo $row['id'];?>"> <br>
							First Name: <input type="text" name="txt_fn" class="form-control" value="<?php echo $row['firstname'];?>"> <br><br>
							Last Name:<input type="text" class="form-control" name="txt_ln" value="<?php echo $row['lastname'];?>"> <br><br>
							Email: <input type="text" class="form-control" name="txt_email" value="<?php echo $row['email'];?>"> <br><br>
                            Gender: <input type="radio" name="gender" value="Male" <?php if($row['gender']=="Male"){    echo "checked";} ?>> Male
                                    <input type="radio" name="gender" value="Female"<?php if($row['gender']=="Female"){echo "checked";} ?>>Female <br><br>
							Mobile: <input type="text" class="form-control" name="txt_mobile" pattern="[0-9]{10}" value="<?php echo $row['mobilenum'];?>"> <br><br>
                            </div>
							<input type="submit" name="btn_sb" class="btn btn-primary" value="Save">&nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="reset" name="Clear" class="btn btn-warning">
							<?php 
                                if(isset($_GET['err']))
                                {
                                    $msg=$_GET['err'];
                                }
                                else
                                {
                                    $msg="";
                                }
                            ?>
                            <h5 style="color:red"><?php echo $msg?> </h5>
	                        </form>
                        </div>
                        </div>
                    </div>
                </div> <br><br>
                <div class="row">
                    <div class="col-md-8 col-lg-offset-2">
                        <div class="panel panel-default">
                            <div class="panel-heading"> <h4><b>Edit User Image </b> </h4>
                            </div>
                        <div class="panel-body">
                            <form class="form-horizontal" method="post" action="updateimgdata.php" enctype="multipart/form-data">
                            <div class="form-group">

                            <input type="hidden" name="txt_id" value="<?php echo $row['id'];?>"> <br>
                            Profile pic: <input type="text" class="form-control" name="pr_img" value="<?php echo $row['profile_pic']?>"> <br><br>
                            Update Profile pic:<input type="file" class="form-control" name="fileToUpload" value="<?php echo $row['profile_pic'];?>">  <br><br>        
                            </div>
                            <input type="submit" name="btn_sb1" class="btn btn-primary" value="Save">&nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="reset" name="Clear" class="btn btn-warning">
            
                            <?php 
                                if(isset($_GET['err1']))
                                {
                                    $msg=$_GET['err1'];
                                }
                                else
                                {
                                    $msg="";
                                }
                            ?>
                            <h5 style="color:red"><?php echo $msg?> </h5>
                            <?php 
                                if(isset($_GET['err2']))
                                {
                                    $msg=$_GET['err2'];
                                }
                                else
                                {
                                    $msg="";
                                }
                            ?>
                            <h5 style="color:red"><?php echo $msg?> </h5>
                            </form>
                        </div>
                        </div>
                    </div>
                </div>
            </div>    
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <footer >
        &copy; 2020 YourCompany | By : <a href="http://www.designbootstrap.com/" target="_blank">Crafts Corner</a>
    </footer>
    <!-- /. FOOTER  -->

    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    <!--VALIDATION SCRIPT -->
    <script type="text/javascript" src="assets/js/parsley.min.js"></script>
    <script>
        $('#demo-form').parsley();
    </script>
</body>
</html>
