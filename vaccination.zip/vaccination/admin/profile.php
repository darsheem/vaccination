<?php
    require 'dbconnect.php';
    session_start();
    $a_id=$_SESSION['a_id'];
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>E-CoVaccine - Admin Dashboard</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="dashboard.php">E-CoVaccine</a>
            </div>

            <div class="notifications-wrapper">
            <ul class="nav text-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user-plus"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li class="divider"></li>
                        <li><a href="profile.php"><i class="fa fa-sign-out"></i>Profile</a></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
            </div>
        </nav>
        <!-- /. NAV TOP  -->

        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <?php
                            $qry="SELECT * FROM user WHERE uid=$a_id";
                            $rs=mysqli_query($conn,$qry);
                            if(mysqli_num_rows($rs)>0)
                            {
                                while($row=mysqli_fetch_assoc($rs))
                                {      
                        ?>
                        <div class="user-img-div">
                            <!-- <img src="<?php echo $row['profile_pic']?>" class="img-circle" /> -->
                            <img src="images/u5.jpg" class="img-circle">
                        </div>
                        <?php 
                                }
                            }
                        ?>
                    </li>

                     <li>
                        <a class="active-menu" href="dashboard.php"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage Vaccine <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addcategory.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Vaccine</a>
                            </li>
                            <li>
                                <a href="viewcategory.php"><i class="glyphicon glyphicon-eye-open "></i>View Vaccine</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-caret-down "></i>Manage Center <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addproduct.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Center</a>
                            </li>
                            <li>
                                <a href="viewproduct.php"><i class="glyphicon glyphicon-eye-open"></i>View Center</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage State <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addstate.php"><i class="glyphicon glyphicon-plus-sign "></i>Add state</a>
                            </li>
                            <li>
                                <a href="viewst.php"><i class="glyphicon glyphicon-eye-open "></i>View state</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage City <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addcity.php"><i class="glyphicon glyphicon-plus-sign "></i>Add city</a>
                            </li>
                            <li>
                                <a href="viewcity.php"><i class="glyphicon glyphicon-eye-open"></i>View city</a>
                            </li>
                        </ul>
                    </li>
        
                    <li>
                        <a href="#"><i class="glyphicon glyphicon-question-sign "></i>Manage Security Question <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="addseq.php"><i class="glyphicon glyphicon-plus-sign "></i>Add Security Question</a>
                            </li>
                            <li>
                                <a href="viewseq.php"><i class="glyphicon glyphicon-eye-open "></i>View Security Question</a>
                            </li>
                        </ul>
                    </li>
                    
                    
                    <!-- <li>
                        <a href="viewfdbk.php"><i class="fa fa-pencil "></i>View Feedback</a>
                    </li>
                    <li>
                        <a href="viewcomplain.php"><i class="fa fa-envelope "></i>View Complain</a>
                    </li>
                    <li>
                        <a href="viewinquiry.php"><i class="glyphicon glyphicon-question-sign"></i>View Inquiry</a>
                    </li> -->
                    <li>
                        <a href="viewusr.php"><i class="fa fa-user "></i>View User</a>
                    </li>
                
                    <li>
                        <a href="viewappoint.php"><i class="fa fa-pencil"></i>View Appointments</a>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- CHECKING IF LOGIN IS DONE OR NOT  -->
        <?php
            if(!isset($_SESSION['a_fn']))
            {
                header("location:index.php");
            }
            $user=$_SESSION["a_fn"];
            //echo "Welcome".$user;
        ?>
        <!-- /. SIDEBAR MENU (navbar-side) -->

        <div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Profile</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-11 col-lg-offset-1">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                               Admin Profile
                            </div>
                        <div class="panel-body">
                           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 toppad" >
   
   
          <div class="panel panel-info">
            <div class="panel-heading" style="background-color: #f5f5f5">
              <h3 class="panel-title" ><b><?php echo $user; ?></b></h3>
            </div>
            <div class="panel-body">
              <div class="row">
                <?php 
                    $qry1="SELECT * FROM user WHERE uid=$a_id";
                    $rs1=mysqli_query($conn,$qry1);
                    if(mysqli_num_rows($rs1)>0)
                    {
                        while($row1=mysqli_fetch_assoc($rs1))
                        {
                ?>
                <div class="col-md-12 col-lg-12 " align="center"> <img alt="User Pic" src="images/u5.jpg" height="80" width="80" class="img-circle img-responsive"> </div>
                
                <div class=" col-md-12 col-lg-12 "> 
                  <table class="table table-user-information">
                    <tbody>
                        <tr>
                            <th>Name</th>
                            <td><?php echo $row1['u_name']?></td>
                        </tr>
                        <tr>
                            <th>Birth Date</th>
                            <td><?php echo $row1['u_birthdate']?></td>
                        </tr>
                        <tr>
                            <th>Gender</th>
                            <td><?php echo $row1['u_gender'];?></td>
                        </tr>
                        <tr>
                            <th>Phone Number</th>
                            <td><?php echo $row1['u_mobile']?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><a href="#"><?php echo $row1['u_email']?></a></td>
                        </tr>
                        
                    </tbody>
                  </table>
                </div>
              </div>            
            </div>
                 <div class="panel-footer">
                        <a href="dashboard.php" data-original-title="Broadcast Message" data-toggle="tooltip" type="button" class="btn btn-sm btn-primary"><i class="fa fa-dashboard"></i> Dashboard</a>

                        <span class="pull-right">
                            <a href="editprofile.php?uid=<?php echo $row1['uid']?>" data-original-title="Edit this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-edit"></i> Edit Profile</a>
                        </span>
                </div>
                <?php
                        }
                    }
                ?>
          </div>
        </div>
                            </div>
                        </div>    
                    </div>
            </div>
        <!-- /. PAGE WRAPPER  -->
    </div></div></div>
    <!-- /. WRAPPER  -->
    <footer >
        &copy;<a href="http://www.designbootstrap.com/" target="_blank">E-CoVaccine</a>
    </footer>
    <!-- /. FOOTER  -->

    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
