<?php
	$id = $_POST['id'];
	require 'dbconnect.php';

    $qry1="SELECT * FROM city_tbl WHERE `state_id`='".$id."'";
    $rs1 = mysqli_query($conn,$qry1);
    if(mysqli_num_rows($rs1)>0)
    {
        while($row1=mysqli_fetch_assoc($rs1))
        {
	?>
	<option value="<?php  echo $row1['id'];?>"><?php  echo $row1['city_name'];?></option>
	<?php
	        }
	    }
?>     