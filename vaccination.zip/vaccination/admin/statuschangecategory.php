<?php
	require 'dbconnect.php';
	//var_dump($_GET);
	$id = $_GET['id'];

	$qry = "SELECT * FROM vaccine WHERE v_id=$id";
	$rs=mysqli_query($conn,$qry);
	$row=mysqli_fetch_assoc($rs);
	$status = $row['v_avail'];
	//echo $status;

	if ($status==0) 
	{
		$qry1="UPDATE vaccine SET `v_avail`=1 WHERE v_id=$id";
		//echo $qry1;
	}
	else
	{
		$qry1="UPDATE vaccine SET `v_avail`=0 WHERE v_id=$id";
		//echo $qry1;
	}

	$rs1=mysqli_query($conn,$qry1);
	if($rs1)
	{
		//echo "Category status changed";
		header("location: viewcategory.php");
		exit();
	}
	else
	{
		echo "Update error";
	}
?>