<?php
	require 'dbconnect.php';
	// var_dump($_GET);
	$id = $_GET['id'];
	$qry = "SELECT * FROM security WHERE s_id=$id";
	$rs=mysqli_query($conn,$qry);
	$row=mysqli_fetch_assoc($rs);
	$status = $row['isactive'];

	if ($status==0) 
	{
		$qry1="UPDATE security SET isactive=1 WHERE s_id=$id";
		// echo $qry1;
	}
	else
	{
		$qry1="UPDATE security SET isactive=0 WHERE s_id=$id";
		// echo $qry1;
	}
	$rs1=mysqli_query($conn,$qry1);
	if($rs1)
	{
		// echo "Security question status changed";
		header("location: viewseq.php");
		exit();
	}
	else
	{
		echo "Update error";
	}
?>