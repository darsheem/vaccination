<?php
	require 'dbconnect.php';
	// var_dump($_POST);

	$id=$_GET['id'];
	// echo $id;

	$qry="SELECT * FROM user_tbl WHERE id=$id";
	$rs=mysqli_query($conn,$qry);
	$row=mysqli_fetch_assoc($rs);
	$status=$row['isactive'];

	if ($status==0) 
	{
		$qry1="UPDATE user_tbl SET isactive=1 WHERE id=$id";
		// echo $qry1;
	}
	else
	{
		$qry1="UPDATE user_tbl SET isactive=0 WHERE id=$id";
		// echo $qry1;
	}

	$rs1=mysqli_query($conn,$qry1);
	if ($rs1) 
	{
		// echo "Status updated";
		header("location:viewusr.php");
		exit();
	}
	else
	{
		echo "Error in updation";
	}
?>	

