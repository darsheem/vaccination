<?php
	require 'dbconnect.php';
	//var_dump($_POST);

	$id=$_POST['txt_id'];
	$fn=$_POST['txt_fn'];
	$ln=$_POST['txt_ln'];
	$email=$_POST['txt_email'];
	$mobile=$_POST['txt_mobile'];
	$gen=$_POST['gender'];
	$pass=$_POST['txt_pass'];
	$cpass=$_POST['txt_cpass'];
	$isactive=1;
	$dt=date("Y-m-d");
	$usertype=2;

	$qry="UPDATE user_tbl SET firstname='".$fn."',lastname='".$ln."',email='".$email."',mobilenum='".$mobile."',gender='".$gen."',dou='".$dt."' WHERE id=$id";
	//echo $qry;
	
	$rs=mysqli_query($conn,$qry);
	if ($rs)
	{
		//echo "Updated successfully";
		header("location:viewusr.php");
	}
	else
	{
		header("location:edituser.php?err=Error in updating user data&id=$id");
		//echo "Update Error";
	}
?>	