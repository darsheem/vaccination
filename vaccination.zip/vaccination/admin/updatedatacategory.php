<?php
	require 'dbconnect.php';
	//var_dump($_POST);

	$id = $_POST['txt_id'];
	$v_name=$_POST['v_name'];
	$v_dose=$_POST['v_dose'];
	$v_dur=$_POST['v_dur'];
	$v_price=$_POST['v_price'];
	$isactive=1;

	$qry="UPDATE vaccine SET v_name='".$v_name."',v_dose='".$v_dose."',v_duration='".$v_dur."',v_price='".$v_price."' WHERE v_id=$id";
	//echo $qry;
	$rs=mysqli_query($conn,$qry);
	if($rs)
	{
		//echo "Updated successfully";
		header("location: viewcategory.php");
		exit();
	}
	else
	{
		header("location:editcategory.php?err=Error in updating category&id=$id");
		//echo "Update error";
	}
?>