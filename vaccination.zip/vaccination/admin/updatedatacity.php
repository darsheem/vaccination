<?php
	require 'dbconnect.php';
	//var_dump($_POST);
	$id= $_POST['id'];
	$state=$_POST['state_id'];
	$city = $_POST['city_name'];

	$qry="UPDATE `city_tbl` SET `city_name`='".$city."',state_id='".$state."' WHERE id='".$id."'";
	//echo $qry;
	$rs=mysqli_query($conn,$qry);
	if($rs)
	{
		//echo "Updated";
		header("location: viewcity.php");
		exit();
	}
	else
	{
		header("location:editcity.php?err=Error in updating city&id=$id");
		//echo "Update error";
	}
?>