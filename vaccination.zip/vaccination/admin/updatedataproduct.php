<?php
	require 'dbconnect.php';
	//var_dump($_POST);
	$id= $_POST['id'];
	$c_name=$_POST['c_name'];
	$state_name=$_POST['sn'];
	$city_name=$_POST['cn'];
	$c_area=$_POST['c_area'];
	$c_addr=$_POST['c_addr'];
	$c_head_name=$_POST['c_head_name'];
	$c_head_email=$_POST['c_head_email'];
	$c_head_pswd = "EVaccine21";
	$isactive=1;

	$qry="UPDATE `center` SET `c_name`='".$c_name."',`c_address`='".$c_addr."',`c_area`='".$c_area."',`c_city`='".$city_name."',`c_state`='".$state_name."',`c_head_name`='".$c_head_name."',`c_head_email`='".$c_head_email."' WHERE c_id='".$id."'";
	//echo $qry;
	$rs=mysqli_query($conn,$qry);
	if($rs)
	{
		//echo "Updated";
		header("location:viewproduct.php");
		exit();
	}
	else
	{
		header("location:editproduct.php?err=Error in updating center data&id=$id");
		//echo "Update error";
	}
?>