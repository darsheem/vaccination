<?php
	require 'dbconnect.php';
	//var_dump($_POST);

	$id=$_POST['txt_id'];
	$fn=$_POST['txt_fn'];
	$mobile=$_POST['txt_cno'];
	$email=$_POST['txt_email'];	

	$qry="UPDATE user SET u_name='".$fn."',u_email='".$email."',u_mobile='".$mobile."' WHERE uid=$id";
	//echo $qry;
	
	$rs=mysqli_query($conn,$qry);
	if ($rs)
	{
		//echo "Updated successfully";
		header("location:profile.php");
	}
	else
	{
		header("location:editprofile.php?id=$id&err=Error in editing profile");
		//echo "Update Error";
	}
?>	