<?php
	require 'dbconnect.php';
	//var_dump($_POST);
	$id = $_POST['txt_id'];
	$sec_que = $_POST['sec_que'];

	$qry="UPDATE `security` SET s_question='".$sec_que."' WHERE s_id=$id";
	//echo $qry;
	$rs=mysqli_query($conn,$qry);
	if($rs)
	{
		//echo "Updated successfully";
		header("location: viewseq.php");
		exit();
	}
	else
	{
		header("location: editseq.php?err=Error in updationg security question&id=$id");
		echo "Update error";
	}
?>