<?php
	require 'dbconnect.php';
	//var_dump($_POST);
	$id = $_POST['txt_id'];
	$sn = $_POST['txt_sn'];
	
	$qry="UPDATE state_tbl SET state_name='".$sn."' WHERE id=$id";
	//echo $qry;
	$rs=mysqli_query($conn,$qry);
	if($rs)
	{
		//echo "Updated successfully";
		header("location: viewst.php");
		exit();
	}
	else
	{
		header("location: editstate.php?err=Error in updating state&id=$id");
		//echo "Update error";
	}
?>