<?php
	require 'dbconnect.php';
	//var_dump($_POST);
	if (!isset($_POST['btn_sb1'])) 
	{
		header("location:edituser.php");
		exit();
	}

	$id= $_POST['txt_id'];
	$pr_img=$_POST['pr_img'];

	if($_FILES["fileToUpload"]["name"]=="")
	{
		//echo "No File Selected";
		header("location:edituser.php?err2=Please select an image to upload&id=$id");
		exit();
	}
	else
	{
		require 'ImageUpload.php';
	} 
	$profile=$target_file;
	$qry="UPDATE user_tbl  SET profile_pic='".$profile."' WHERE id='".$id."'";
	// echo $qry;

	$rs=mysqli_query($conn,$qry);
	if($rs)
	{
		// echo "Updated";
		header("location:viewuser.php");
		exit();
	}
	else
	{
		header("location:edituser.php?err1=Error in updating profile image&id=$id");
		// echo "Update error";
	}
?>