<?php
	require 'dbconnect.php';
	//var_dump($_POST);
	if (!isset($_POST['btn_sb1'])) 
	{
		header("location:editprofile.php");
		exit();
	}

	$id= $_POST['txt_id'];
	$pr_img=$_POST['pr_img'];
	$dt=date("Y-m-d");

	if($_FILES["fileToUpload"]["name"]=="")
	{
		// echo "No File Selected";
		header("location:editprofile.php?err2=Please select an image to upload&id=$id");
		exit();
	}
	else
	{
		require 'ImageUpload.php';
	} 
	$profile=$target_file;
	$qry="UPDATE user_tbl  SET profile_pic='".$profile."',dou='".$dt."' WHERE id='".$id."'";
	// echo $qry;
	//.exit();

	$rs=mysqli_query($conn,$qry);
	if($rs)
	{
		// echo "Updated";
		header("location:profile.php");
		exit();
	}
	else
	{
		header("location:editprofile.php?err1=Error in updating profile image&id=$id");
		// echo "Update error";
	}
?>