<?php
  	require 'dbconnect.php';

	//$conn=mysqli_connect("localhost","root","","vaccination") or die('Mysql Connection Error'. mysqli_connect_error());

  	session_start();

	if (!isset($_POST["btn_sb"]))
	{
	 	header("location:index.php");
	 	exit();
	}

	$us=$_POST['un'];
	$ps=$_POST['txt_pass'];

	$qry= "SELECT * FROM center WHERE c_head_email='$us' AND c_head_password='$ps'";

	$rs=mysqli_query($conn,$qry);
	if (mysqli_num_rows($rs)>0) 
	{

		$row=mysqli_fetch_assoc($rs);
		$_SESSION['c_head_name']=$row['c_head_name'];
		$_SESSION['c_name']=$row['c_name'];

		if (isset($_POST['remember'])) 
		{
			setcookie("a_user",$us,time()+(86400 * 30), "/");
			setcookie("a_pass",$ps,time()+(86400 * 30), "/");
		}

		header("location:dashboard.php");
		exit();
	}	

	header("location:index.php?err=Invalid username or password");
?>