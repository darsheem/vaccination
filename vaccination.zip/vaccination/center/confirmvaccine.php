<?php
	
	require 'dbconnect.php';
    session_start();
     
    if(!isset($_SESSION['c_head_name']))
    {
        header("location:index.php");
    }

    $c_head_name=$_SESSION['c_head_name'];
    $cname=$_SESSION['c_name'];

    $u_name = $_REQUEST['u_name'];
    $v_name = $_REQUEST['v_name'];

    $qry="SELECT * FROM vaccine_booked WHERE u_name='$u_name' AND v_name='$v_name'";

    //echo "$qry";
    $rs=mysqli_query($conn,$qry);
    if (mysqli_num_rows($rs)>0) 
    {
    	//echo "Done";
        while ($row=mysqli_fetch_assoc($rs)) 
        {
        	$dose = $row['dose_remain'];
        	
        	
        		$dose -= 1;
        		$query = "UPDATE vaccine_booked SET dose_remain = $dose WHERE u_name='$u_name' AND v_name='$v_name'";
        		$result=mysqli_query($conn,$query);

        		if($dose == 0){
        			$q = "UPDATE vaccine_booked SET v_status = 1 WHERE u_name='$u_name' AND v_name='$v_name'";
        			$r=mysqli_query($conn,$q);

        			
        		}
        
        }
    }
    echo "<script>window.location='viewappointment.php'</script>"

?>