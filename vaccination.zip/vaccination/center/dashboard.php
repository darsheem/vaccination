﻿<!-- CHECKING IF LOGIN IS DONE OR NOT  -->
<?php
    require 'dbconnect.php';
    session_start();
    if(!isset($_SESSION['c_head_name']))
    {
        header("location:index.php");
    }
    $c_head_name=$_SESSION['c_head_name'];
    $cname=$_SESSION['c_name'];

    $qry7 = "SELECT * FROM vaccine_booked WHERE v_c_name = '$cname' AND v_status = 0";
    $rs7=mysqli_query($conn,$qry7);
    $u=mysqli_num_rows($rs7);

    $qry7 = "SELECT * FROM vaccine_booked WHERE v_c_name = '$cname' AND v_status = 1";
    $rs7=mysqli_query($conn,$qry7);
    $c=mysqli_num_rows($rs7);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>E-Co Vaccine- Dashboard</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- ANIMATION CSS-->
    <link rel="stylesheet" href="assets/css/animate.css"> 
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="dashboard.php">E-Co Vaccine </a>
            </div>

            <div class="notifications-wrapper">
                <ul class="nav text-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user-plus"></i>  <i class="fa fa-caret-down"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user ">
                            <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- /. NAV TOP  -->

        <nav  class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <?php
                            $qry="SELECT * FROM center WHERE c_head_name='$c_head_name'";
                            $rs=mysqli_query($conn,$qry);
                            if(mysqli_num_rows($rs)>0)
                            {
                                while($row=mysqli_fetch_assoc($rs))
                                {      
                        ?>
                        <div class="user-img-div">
                            <img src="images/u5.jpg" class="img-circle">
                        </div>
                        <?php 
                                }
                            }
                        ?>
                    </li>
                    
                    <li>
                        <a class="active-menu"  href="dashboard.php"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Manage User <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        
                            <li>
                                <a href="viewappointment.php"><i class="glyphicon glyphicon-eye-open "></i>View Appointment</a>
                            </li>
                        </ul>
                    </li>
                    
                </ul>
            </div>
        </nav>          
        <!-- /. SIDEBAR MENU (navbar-side) -->

        <div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12 animated slideInRight">
                        <h1 class="page-head-line">Dashboard-<?php echo $cname; ?></h1>
                    </div>
                </div>

               
            <div class="row">
                
                <div class=" col-md-3 col-sm-3">
                    <div class="style-box-one Style-one-clr-four">
                        <a href="viewappointment.php">
                            <h3> UP COMING</h3>
                            <h4><?php echo $u ?></h4>
                        </a>
                    </div>
                </div>    

                 <div class=" col-md-3 col-sm-3">
                    <div class="style-box-one Style-one-clr-three">
                        <a href="viewcomplete.php">
                            <h3> COMPLETED</h3>
                            <h4><?php echo $c ?></h4>
                        </a>
                    </div>
                </div>  

            </div>

            </div>  

            <div class="row"> 
            </div> 
            </div>
        </div>     
            <!-- /. PAGE INNER  -->
    </div>
       
    <footer >
        &copy; 2020 YourCompany | By : <a href="http://www.designbootstrap.com/" target="_blank">CraftsCorner</a>
    </footer>
    
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
