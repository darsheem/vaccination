<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="vaccination";

	//Create connection
	$conn=mysqli_connect($servername,$username,$password);

	//Check connection
	if (!$conn)
	{
		die("Connection failed: ".mysqli_connect_error());
	}
	//echo "Connected successfully"."<br>";

	$db=mysqli_select_db($conn,$dbname);
	if ($db)
	{
		//echo "Database $dbname selected <br><br>";	# code...
	}
	else
	{
		//echo "Database not selected <br><br>";
	}
?>	