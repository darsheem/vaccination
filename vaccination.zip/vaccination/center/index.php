<?php
    session_start();
    if(isset($_SESSION['a_fn']))
    {
        header("location:dashboard.php");
    }
    if(isset($_COOKIE['a_user']))
    {
        $un=$_COOKIE['a_user'];
        $ps=$_COOKIE['a_pass'];
    }
    else
    {
        $un="";
        $ps="";
    }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>E-Vaccination - Admin Login</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- ANIMATION CSS-->
    <link rel="stylesheet" href="assets/css/animate.css"> 
</head>
<body class="logincolor">
    <div id="wrapper">
        <div class="">
            <div class="container">
                <div class="row main">
                    <div class="panel-heading">
                       <div class="panel-title text-center animated slideInDown">
                            <h1 class="title">E-Vaccination</h1>
                            <hr />
                        </div>
                    </div> 
                    <div class="main-login main-center">
                        <form class="form-horizontal" method="post" action="checklogin.php">
                            
                            <div class="form-group">
                                <label for="email" class="cols-sm-2 control-label">Email</label>
                                <div class="cols-sm-10">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
                                        <input type="email" class="form-control" name="un" placeholder="Enter your Email" value="<?php echo $un; ?>" required=""/>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="password" class="cols-sm-2 control-label">Password</label>
                                <div class="cols-sm-10">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                                        <input type="password" class="form-control" name="txt_pass" placeholder="Enter your Password" value="<?php echo $ps; ?>"required=""/>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <!-- <label for="password" class="cols-sm-2 control-label">Password</label> -->
                                <div class="cols-sm-10">
                                    <div class="input-group">
                                        <!-- <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span> -->
                                        <!-- <input type="password" class="form-control" placeholder="Enter your Password" required=""/> -->
                                        <input type="checkbox" name="remember" value="1"><b> Remember Me </b><br>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group ">
                                <input type="submit" name="btn_sb" value="Login" class="btn btn-primary btn-lg btn-block login-button">      
                            </div>
                            <?php
                                if(isset($_GET['err']))
                                {
                                    $msg=$_GET['err'];
                                } 
                                else
                                {
                                    $msg="";
                                }
                            ?>
                            <h4 style="color:red"> <?php echo $msg; ?> </h4>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <br>
    </div>
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
