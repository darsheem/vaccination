<?php 
    require 'dbconnect.php';
    session_start();
     
    if(!isset($_SESSION['c_head_name']))
    {
        header("location:index.php");
    }

    $c_head_name=$_SESSION['c_head_name'];
    $cname=$_SESSION['c_name'];
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>E-CoVaccine - Admin Dashboard</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="dashboard.php">E-CoVaccine</a>
            </div>

            <div class="notifications-wrapper">
                <ul class="nav text-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user-plus"></i>  <i class="fa fa-caret-down"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li class="divider"></li>
                            <li><a href="profile.php"><i class="fa fa-sign-out"></i>Profile</a> </li>
                            <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- /. NAV TOP  -->
        <nav  class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <?php
                            $qry="SELECT * FROM center WHERE c_head_name='$c_head_name'";
                            $rs=mysqli_query($conn,$qry);
                            if(mysqli_num_rows($rs)>0)
                            {
                                while($row=mysqli_fetch_assoc($rs))
                                {      
                        ?>
                        <div class="user-img-div">
                            <img src="images/u5.jpg" class="img-circle">
                        </div>
                        <?php 
                                }
                            }
                        ?>
                    </li>
                    
                    <li>
                        <a href="dashboard.php"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                    
                    <li>
                        <a href="#" class="active-menu"><i class="fa fa-sitemap "></i>Manage User <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        
                            <li>
                                <a href="viewappointment.php"><i class="glyphicon glyphicon-eye-open "></i>View Appointment</a>
                            </li>
                        </ul>
                    </li>
                    
                </ul>
            </div>
        </nav>   
        <!-- /. SIDEBAR MENU (navbar-side) -->

        <div id="page-wrapper" class="page-wrapper-cls">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">View Users</h1>
                    </div>
                </div>
                <!--<div class="row">
                <div class="col-md-10 col-lg-offset-1">--> 
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Users
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>User Name</th>
                                            <th>Vaccine Name</th>
                                            <th>Center Name</th>
                                            <th>Start Date</th>
                                            <th>Dose 1</th>
                                            <th></th>
                                                                                
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $qry="SELECT * FROM vaccine_booked WHERE v_status=0";
                                            $rs=mysqli_query($conn,$qry);
                                            if (mysqli_num_rows($rs)>0) 
                                            {
                                                while ($row=mysqli_fetch_assoc($rs)) 
                                                {
                                                    
                                        ?>
                                        <tr>
                                            <td><?php echo $row['u_name']?></td>
                                            <td><?php echo $row['v_name']?></td>
                                            <td><?php echo $row['v_c_name']?></td>
                                            <td><?php echo $row['v_b_date']?></td>
                                            <td><?php echo $row['v_b_dose']?></td>
                                            <td><?php echo "<a href='confirmvaccine.php?u_name=".$row['u_name']."&v_name=".$row['v_name']."'>Confirm</a>"?></td>
                                        </tr>
                                        <?php
                                                }
                                            }
                                        ?>  
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
             <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <footer >
        &copy;<a href="http://www.designbootstrap.com/" target="_blank">E-CoVaccine</a>
    </footer>
    <!-- /. FOOTER  -->

    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
