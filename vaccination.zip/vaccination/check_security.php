<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

	<title>Forgot Password</title>
	<style type="text/css">
		body{
			margin: 0;
			padding: 0;
			background: url('indexback.jpg');
			background-size: cover;
			background-repeat: no-repeat;
			font-family: sans-serif;
		}
		.box{
			width: 420px;
			height: 300px;
			background : #0A3E5C;
			color: #fff;
			top: 25%;
			left: 35%;
			position: absolute;
			transition: translate(-50%,-50%);
			box-sizing: border-box;
			padding: 40px;
		}
		.box input{
			width: 100%;
			margin-bottom: 20px;
		}
		.box p{
			margin: 0;
			padding: 0;
			font-weight: bold;
		}
		input[type='text'], input[type='email'], input[type='password']{
			border: none;
			color: #fff;
			border-bottom: 1px solid #fff;
			background: transparent;
			outline: none;
			height: 40px;
		}
		input[type='submit']{
			color: black;
			background-color: #A9CCE3;
			font-size: 17px;
			padding: 10px;
			border-radius: 10px;
		}
		select{
			width: 360px; 
			height: 40px; 
			background-color: #1B2631;
			color: white;
			padding: 5px;
			border-radius: 10px;
			margin-bottom: 30px;
		}
		.error{
			color: red;
		}

	</style>
</head>

<body>
	<div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex align-items-center justify-content-center justify-content-md-between">
      <div class="align-items-center d-none d-md-flex">
        <i class="bi bi-clock"></i> Monday - Saturday, 8AM to 10PM
      </div>
      <div class="d-flex align-items-center">
        <i class="bi bi-phone"></i> Call us now +1 5589 55488 55
      </div>
    </div>
  </div>

  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto">E-Co Vaccine</a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto " href="index.php">Home</a></li>
          <li><a class="nav-link scrollto" href="index.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      
    </div>
  </header>

	<div class="box">
	<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">

		

		<p>Security Question <span class="error">*</span></p>
		<?php
			$con=mysqli_connect("localhost","root","","vaccination") or die('Mysql Connection Error'. mysqli_connect_error());

			$email = $_SESSION['email'];

			$query="SELECT u_email, u_security FROM user WHERE u_email='$email'";

			$result=mysqli_query($con,$query);
			
			while ($row = mysqli_fetch_array($result)) {
				echo $row['u_security'];
				$que = $row['u_security'];
			}			
		?>
		</br></br>
		<p>Security Answer <span class="error">*</span></p>
		<input type="text" name="ans" placeholder="Your Answer" required/>


	<input type="submit" name="validate" value="Validate">

	<?php
		if (isset($_POST['validate'])) {
			
			$ans = $_POST['ans'];

			$query="SELECT u_email, u_security, u_security_ans FROM user WHERE u_email='$email'";
		
			$result=mysqli_query($con,$query);
			
			while ($row = mysqli_fetch_array($result)) {
				
				if($row['u_security'] == $que && $row['u_security_ans'] == $ans){
				
					echo "<script>window.location='new_password.php'</script>";
				}
				else{
					echo "<script>alert('Wrong')</script>";
				}
			}

		}
	?>
</form>
</div>
</body>
</html>