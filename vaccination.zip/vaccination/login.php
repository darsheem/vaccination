<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Vaccination Login</title>
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">



<style type="text/css">
	body{
		margin: 0;
		padding: 0;
		background: url('indexback.jpg');
		background-size: cover;
		background-repeat: no-repeat;
		font-family: sans-serif;

	}
	.loginbox{
		width: 420px;
		height: 500px;
		background : #0A3E5C;
		color: #fff;
		top: 20%;
		left: 8%;
		position: absolute;
		transition: translate(-50%,-50%);
		box-sizing: border-box;
		padding: 70px 30px;
	}
	h1{
		margin: 0;
		padding: 0 0 20px;
		text-align: center;
		font-size: 24px;
	}
	h2{
		margin: 0;
		padding: 0 0 20px;
		text-align: center;
		font-size: 21px;
	}
	.loginbox p{
		margin: 0;
		padding: 0;
		font-weight: bold;
	}
	.loginbox input{
		margin-bottom: 20px;
	}
	.loginbox input[type="text"], input[type="password"]{
		width: 100%;
		border: none;
		color: #fff;
		border-bottom: 1px solid #fff;
		background: transparent;
		outline: none;
		height: 40px;
	}
	.loginbox input[type="submit"]{
		width: 100%;
		outline: none;
		height: 40px;
		background: #091A23;
		color: #fff;
		font-size: 18px;
		border-radius: 20px;
		border-color: #fff solid;
	}
	.loginbox input[type="submit"]:hover{
		cursor: pointer;
		background: #A9CCE3;
		color: #000;
	}
	.loginbox a{
		text-decoration: none;
		font-size: 15px;
		line-height: 20px;
		color: darkgrey;
	}
	
	select{
		width: 360px; 
		height: 40px; 
		background-color: #1B2631;
		color: white;
		padding: 5px;
		border-radius: 10px;
		margin-bottom: 30px;
	}
</style>
</head>

<body>
	<div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex align-items-center justify-content-center justify-content-md-between">
      <div class="align-items-center d-none d-md-flex">
        <i class="bi bi-clock"></i> Monday - Saturday, 8AM to 10PM
      </div>
      <div class="d-flex align-items-center">
        <i class="bi bi-phone"></i> Call us now +1 5589 55488 55
      </div>
    </div>
  </div>

  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto">E-Co Vaccine</a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto " href="index.php">Home</a></li>
          <li><a class="nav-link scrollto" href="index.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      
    </div>
  </header>

<div class="loginbox">
	<h1>Vaccination Management</h1>
	<h2>Login Here</h2>
	<form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">

		<p>Username</p>
		<input type="text" name="uname" placeholder="Enter Name">
		<p>Password</p>
		<input type="password" name="password" placeholder="Enter Password">
		
		<center><a href="forgot_pass.php"><b> Forgot Password? </b></a></center>
		</br>
		<input type="submit" name="login" value="Login"/>
		<center>Don't have an account yet?<a href="register.php" ><b> Register</b></a></center>
	

	<?php
		if (isset($_POST['login'])){

			$con=mysqli_connect("localhost","root","","vaccination") or die('Mysql Connection Error'. mysqli_connect_error());

			$uname=$_POST['uname'];
			$password=$_POST['password'];

			$query="SELECT u_name, u_pass, u_type FROM user WHERE u_name='$uname' and u_type='2'";
		
			$result=mysqli_query($con,$query);
		
			while ($row = mysqli_fetch_array($result)) {
				if ($row['u_name'] == $uname && $row['u_pass'] == $password && $row['u_type'] == '2') {
					$_SESSION['username'] = $uname;
					echo "<script>window.location='userdashboard.php'</script>";				
				}
				else{
					echo '<p>Please enter valid credentails</p>';
				}
			}	
			

		}
	?>

</div>
</form>
</body>
</html>