<?php
	$con=mysqli_connect("localhost","root","","vaccination") or die('Mysql Connection Error'. mysqli_connect_error());
?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Vaccination Register</title>

  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

<style type="text/css">
	body{
		background: url('indexback.jpg');
		background-size: cover;
		background-repeat: initial;
		font-family: sans-serif;
	}
	.loginbox{
		width: 460px;
		height: 1150px;
		background : #0A3E5C;
		color: #fff;
		top: 20%;
		left: 8%;
		position: absolute;
		box-sizing: border-box;
		padding: 50px 30px;
	}
	h1{
		padding: 0 0 20px;
		text-align: center;
		font-size: 24px;
	}
	h2{
		margin: 0;
		padding: 0 0 20px;
		text-align: center;
		font-size: 21px;
	}
	.loginbox p{
		margin: 0;
		padding: 0;
		font-weight: bold;
	}
	.loginbox input{
		margin-bottom: 20px;
	}
	.loginbox input[type="text"], input[type="password"], input[type="email"], input[type="number"]{
		width: 100%;
		border: none;
		color: #fff;
		border-bottom: 1px solid #fff;
		background: transparent;
		outline: none;
		height: 40px;
	}
	.loginbox input[type="date"]{
		width: 360px; 
		height: 30px; 
		background-color: #1B2631;
		color: white;
	}
	.loginbox input[type="submit"]{
		width: 100%;
		outline: none;
		height: 40px;
		background: #091A23;
		color: #fff;
		font-size: 18px;
		border-radius: 20px;
		border-color: #fff solid;
	}
	.loginbox input[type="submit"]:hover{
		cursor: pointer;
		background: #A9CCE3;
		color: #000;
	}
	.loginbox a{
		text-decoration: none;
		font-size: 15px;
		line-height: 20px;
		color: darkgrey;
	}
	.error{
	    color: red;
	}
	select{
		width: 360px; 
		height: 40px; 
		background-color: #1B2631;
		color: white;
		padding: 5px;
		border-radius: 10px;
		margin-bottom: 30px;
	}

</style>
</head>

<body>

<div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex align-items-center justify-content-center justify-content-md-between">
      <div class="align-items-center d-none d-md-flex">
        <i class="bi bi-clock"></i> Monday - Saturday, 8AM to 10PM
      </div>
      <div class="d-flex align-items-center">
        <i class="bi bi-phone"></i> Call us now +1 5589 55488 55
      </div>
    </div>
  </div>

  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto">E-Co Vaccine</a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto " href="index.php">Home</a></li>
          <li><a class="nav-link scrollto" href="index.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      
    </div>
  </header>

<div class="loginbox">
	<h1>Vaccination Management</h1>
	<h2>Registration Here</h2>
	<form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">

		<p>Username <span class="error">*</span></p>
		<input type="text" name="uname" placeholder="Username">
	
		<p>Gender<span class="error">*</span> </p></br>
		<input type="radio" name="gender" value="Male">Male</input>
		<input type="radio" name="gender" value="Female">Female</input>
		
		<p>City <span class="error">*</span></p>
		<select name="city" class="option" required>
		    <option value="none" selected disabled hidden> Select an city</option>
		    <option value="Surat">Surat</option>
		    <option value="Ahmedabad">Ahmedabad</option>
		    <option value="Vadodara">Vadodara</option>
		    <option value="Bharuch">Bharuch</option>
		    <option value="Vapi">Vapi</option>
		    <option value="Vapi">Valasad</option>
	    </select> 

	    <p>State <span class="error">*</span></p>
		<select name="state" class="option" required>
		    <option value="none" selected disabled hidden> Select an state</option>
		    <option value="Gujarat">Gujarat</option>
		    <option value="Maharastra">Maharastra</option>
		    <option value="Punjab">Punjab</option>
	    </select>
	    
	    <p>Birth Date <span class="error">*</span></p>
	    <input type="date" name="birth" class="option" required/>

		<p>Email <span class="error">*</span></p>
		<input type="email" name="email" placeholder="Email address" required/>

		<p>Mobile <span class="error">*</span></p>
		<input type="number" name="mobile" placeholder="Email Mobile" required/>

		<p>Password <span class="error">*</span></p>
		<input type="password" name="password" placeholder="Enter Password" required>
		
		<p>Security Question <span class="error">*</span></p>
		<select name="que" required>
			<option value="none" selected disabled hidden> Select an Question</option>
			<?php
				$query = "SELECT s_question FROM security";
          		$result=mysqli_query($con,$query);

          		while ($row = mysqli_fetch_array($result)) {
          			echo "<option value='".$row['s_question']."'>".$row['s_question']."</option>";
          		}
          	?>
		</select>

		<p>Security Answer <span class="error">*</span></p>
		<input type="text" name="ans" placeholder="Your Answer" required/>

		<input type="submit" name="register" value="Register">
		<center>Already have an Account? <a href="login.php"><b>Login</b></a></center>
		
	

	<?php
		if (isset($_POST['register'])){

			$name=$_POST['uname'];
			$gen = $_POST['gender'];
			$city = $_POST['city'];
			$state = $_POST['state'];
			$birth = $_POST['birth'];
			$mobile = $_POST['mobile'];
			$email = $_POST['email'];
			$pass=$_POST['password'];
			$que = $_POST['que'];
			$ans = $_POST['ans'];

			$query="INSERT INTO user(u_name, u_birthdate, u_email, u_mobile ,u_gender, u_pass, u_security, u_security_ans, u_city, u_type, u_state) 
								VALUES('$name', '$birth', '$email', $mobile,'$gen', '$pass', '$que', '$ans', '$city', '2', '$state')";

			$result=mysqli_query($con,$query);

			echo $query;
			if(!$result)
			{
				die("<br>Can't Insert Data : " .mysqli_error());
			}
			echo "<script>alert('User Record Inserted..!!');window.location='login.php'</script>";
		}

	?>
</form>
</div>
</body>
</html>
