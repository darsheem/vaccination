<?php
	session_start();

	$con=mysqli_connect("localhost","root","","vaccination") or die('Mysql Connection Error'. mysqli_connect_error());

	$uname = $_SESSION['username'];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Take Appointment</title>
	<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="style_appointment.css">

  <script type="text/javascript">
  	// function EnableCenter(cityselect){

  	// 	var selectedValue = cityselect.options[cityselect.selectedIndex].value;
   //    var center = document.getElementById("centerselect");
   //    //center.disabled = selectedValue == 5 ? false : true;
      
   //    if (!center.disabled) {
   //        center.focus();
   //    }
  	// }
  </script>
</head>

<body background="appointment_back.jpg" style="background-repeat: no-repeat; background-size: cover;">

	<div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex align-items-center justify-content-center justify-content-md-between">
      <div class="align-items-center d-none d-md-flex">
        <i class="bi bi-clock"></i> Monday - Saturday, 8AM to 10PM
      </div>
      <div class="d-flex align-items-center">
        <i class="bi bi-phone"></i> Call us now +1 5589 55488 55
      </div>
    </div>
  </div>

  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto">E-Co Vaccine</a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
        	<li><a class="nav-link scrollto " href="userdashboard.php">Home</a></li>
          <li><a class="nav-link scrollto " href="take_appointment.php" >Take appointment</a></li>
          <li><a class="nav-link scrollto" href="view.php">View</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      
      <a href='userprofile.php' class='appointment-btn scrollto' target='_self'><?php echo $_SESSION['username']; ?></a>
      <a href='signout.php' class='appointment-btn scrollto' target='_self'>Sign out</a>
    </div>
  </header>

	
  <form method="POST" action="<?php $_SERVER['PHP_SELF'] ?>">
  <div class="box">
  	<div class="leftbox"></div>

  	<div class="rightbox">
  		<div class="profile_tabshow">
  			<h1><b>Appointment</b></h1>

  			<h2>Vaccine Name</h2>
  			<?php

				$query="SELECT v_name FROM vaccine";
				$result=mysqli_query($con,$query);
				
				echo "<select name='vname'>";
				while ($row = mysqli_fetch_array($result)) {
					echo "<option value='".$row['v_name']."'>".$row['v_name']."</option>";
				}
				echo "</select>";

			?>
  
  			<h2>Start Date</h2>
  			<p><input type="date" name="start_date" required></p>

  			<h2>Center</h2>
  			<?php
				
          $query = "SELECT u_city FROM user WHERE u_name = '$uname'";
          $result=mysqli_query($con,$query);

          while ($row_user = mysqli_fetch_array($result)) {
          
    				$query_city = "SELECT * FROM city_tbl WHERE city_name = '".$row_user['u_city']."'";
    				$result_city = mysqli_query($con,$query_city);
    				
    				echo "<select name='center'>
                    <option value='none' selected disabled hidden> Select an Option</option>";

    				while ($row_city = mysqli_fetch_array($result_city)) {

                echo $row_city['id'];

                $qu="SELECT c_city, c_name FROM center";
                $res=mysqli_query($con,$qu);

                while ($row_center = mysqli_fetch_array($res)) {
                  
                  if ($row_center['c_city'] == $row_city['id']) {
      						  echo "<option value='".$row_center['c_name']."'>".$row_center['c_name']."</option>";
                  }
    					 }
            }
          }
				
				echo "</select>";
			?>

  			<input type="submit" name="confirm" value="Confirm">
  		</div>
  	</div>
  </div>

  <?php
  	if (isset($_POST['confirm'])) {
  		
  		$vname = $_POST['vname'];
  		$start_date = $_POST['start_date'];
  		$center = $_POST['center'];

  		$query="SELECT * FROM vaccine WHERE v_name='$vname'";
  		$result=mysqli_query($con,$query);
  				
      //global $v_dose;
  		while ($row = mysqli_fetch_array($result)) {
  			$v_duration = $row['v_duration'];
        $_SESSION['v_dose'] = $row['v_dose'];
  		}

      $time = strtotime($start_date);
      $sec_dose = date("Y-m-d", strtotime('+3 week', $time));

      $dose = $_SESSION['v_dose'];
  		$query = "INSERT INTO vaccine_booked(u_name, v_name, v_c_name, v_b_date, v_b_dose, v_status, dose_remain) VALUES('$uname', '$vname','$center','$start_date', '$sec_dose', 0, $dose)";

      echo "<script>$query</script>";
      $res = mysqli_query($con,$query);
      if (!$res) {
          die('Insert'. mysql_error());
      }

      echo "<script>window.location='view.php'</script>";
  	}
  ?>
</form>
</body>
</html>