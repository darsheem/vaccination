<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>User profile</title>
	<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="style.css">

 
</head>

<body background="userdashboard.jpg">

<div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex align-items-center justify-content-center justify-content-md-between">
      <div class="align-items-center d-none d-md-flex">
        <i class="bi bi-clock"></i> Monday - Saturday, 8AM to 10PM
      </div>
      <div class="d-flex align-items-center">
        <i class="bi bi-phone"></i> Call us now +1 5589 55488 55
      </div>
    </div>
  </div>

  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto">E-Co Vaccine</a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto " href="userdashboard.php">Home</a></li>
          <li><a class="nav-link scrollto " href="take_appointment.php">Take appointment</a></li>
          <li><a class="nav-link scrollto" href="view.php">View</a></li>

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
		<a href='signout.php' class='appointment-btn scrollto' target='_self'>Sign out</a>

    </div>
  </header>
<?php

	$con=mysqli_connect("localhost","root","","vaccination") or die('Mysql Connection Error'. mysqli_connect_error());

	$uname = $_SESSION['username'];
	$query="SELECT * FROM user WHERE u_name='$uname'";

	$result=mysqli_query($con,$query);
			
	while ($row = mysqli_fetch_array($result)) {
		
?>

  <div class="box">
  	<div class="leftbox"></div>

  	<div class="rightbox">
  		<div class="profile_tabshow">
  			<h1><b>About</b></h1>

  			<h2>Username</h2>
  			<p><?php echo $row['u_name']; ?></p>
  
  			<h2>Birthdate</h2>
  			<p><?php echo $row['u_birthdate']; ?></p>

  			<h2>Email</h2>
  			<p><?php echo $row['u_email']; ?></p>

  			<h2>Mobile</h2>
  			<p><?php echo $row['u_mobile']; ?></p>

  			<h2>Gender</h2>
  			<p><?php echo $row['u_gender']; ?></p>

  			<h2>City</h2>
  			<p><?php echo $row['u_city']; ?></p>

  			<h2>State</h2>
  			<p><?php echo $row['u_state']; ?></p>

  		</div>
  	</div>
  </div>

<?php } ?>
	
	<!-- <center><a href="signout.php" class="signout">Sign Out</a></center> -->
</body>
</html>