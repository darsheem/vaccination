-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2021 at 08:16 AM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vaccination`
--

-- --------------------------------------------------------

--
-- Table structure for table `center`
--

CREATE TABLE IF NOT EXISTS `center` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(50) NOT NULL,
  `c_address` varchar(100) NOT NULL,
  `c_area` varchar(50) NOT NULL,
  `c_city` varchar(50) NOT NULL,
  `c_state` varchar(50) NOT NULL,
  `c_u_id` int(11) NOT NULL,
  `c_head_name` varchar(50) NOT NULL,
  `c_head_email` varchar(50) NOT NULL,
  `c_head_password` varchar(50) NOT NULL,
  `isactive` int(11) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `center`
--

INSERT INTO `center` (`c_id`, `c_name`, `c_address`, `c_area`, `c_city`, `c_state`, `c_u_id`, `c_head_name`, `c_head_email`, `c_head_password`, `isactive`) VALUES
(1, 'Vikas Nursing Home', 'Payal Avenue Near, Naranpura Railway crossing', 'Naranpura', '1', '1', 0, 'Paresh Patel', 'paresh@gmail.com', 'EVaccine21', 1),
(2, 'Reyansh Nursing', ' Arham Arcade, Near Shilpa Jewellers', 'Palace Road', '2', '1', 0, 'Reyansh', 'reyansh@yahoo.co.in', 'EVaccine21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `city_tbl`
--

CREATE TABLE IF NOT EXISTS `city_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(50) NOT NULL,
  `state_id` int(11) NOT NULL,
  `isactive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `city_tbl`
--

INSERT INTO `city_tbl` (`id`, `city_name`, `state_id`, `isactive`) VALUES
(1, 'Ahmedabad', 1, 1),
(2, 'Rajkot', 1, 1),
(3, 'Vadodra', 1, 1),
(4, 'Surat', 1, 1),
(5, 'Mumbai', 2, 1),
(6, 'Pune', 2, 1),
(7, 'Hii', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `security`
--

CREATE TABLE IF NOT EXISTS `security` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_question` varchar(50) NOT NULL,
  `isactive` int(11) NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `security`
--

INSERT INTO `security` (`s_id`, `s_question`, `isactive`) VALUES
(1, 'What is your Nick name?', 1),
(2, 'What is your Sun sign?', 1),
(3, 'What is your Birth place?', 1),
(4, 'What is your favorite Sport?', 1),
(5, 'What is your favorite Color?', 1),
(6, 'What is your favorite Pass time?', 1);

-- --------------------------------------------------------

--
-- Table structure for table `state_tbl`
--

CREATE TABLE IF NOT EXISTS `state_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(50) NOT NULL,
  `isactive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `state_tbl`
--

INSERT INTO `state_tbl` (`id`, `state_name`, `isactive`) VALUES
(1, 'Gujarat', 1),
(2, 'Maharashtra', 1),
(3, 'Punjab', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(50) NOT NULL AUTO_INCREMENT,
  `u_name` varchar(50) NOT NULL,
  `u_birthdate` date NOT NULL,
  `u_email` varchar(50) NOT NULL,
  `u_mobile` int(10) DEFAULT NULL,
  `u_gender` varchar(50) NOT NULL,
  `u_pass` varchar(50) NOT NULL,
  `u_security` varchar(50) NOT NULL,
  `u_security_ans` varchar(50) NOT NULL,
  `u_city` varchar(50) NOT NULL,
  `u_type` varchar(50) NOT NULL,
  `u_state` varchar(50) NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `u_mobile` (`u_mobile`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `u_name`, `u_birthdate`, `u_email`, `u_mobile`, `u_gender`, `u_pass`, `u_security`, `u_security_ans`, `u_city`, `u_type`, `u_state`) VALUES
(2, 'Mansi', '2001-04-13', 'mansi@gmail.com', 2, 'Female', 'Mansi@1234', 'Which is your favourite color?', 'Black', 'Surat', '2', 'Gujarat'),
(4, 'burte force', '2010-04-12', 'burteforce@gmail.com', 0, 'Male', 'bruteforce', '', '', '', '1', ''),
(5, 'Darshee', '2000-02-13', 'darshee@gmail.com', 2147483647, 'Female', 'Mansi@123', 'What is your favorite Color?', 'Black', 'Ahmedabad', '2', 'Gujarat');

-- --------------------------------------------------------

--
-- Table structure for table `vaccine`
--

CREATE TABLE IF NOT EXISTS `vaccine` (
  `v_id` int(50) NOT NULL AUTO_INCREMENT,
  `v_name` varchar(50) NOT NULL,
  `v_dose` int(50) NOT NULL,
  `v_duration` int(11) NOT NULL,
  `v_price` int(50) NOT NULL,
  `v_avail` tinyint(1) NOT NULL,
  PRIMARY KEY (`v_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `vaccine`
--

INSERT INTO `vaccine` (`v_id`, `v_name`, `v_dose`, `v_duration`, `v_price`, `v_avail`) VALUES
(1, 'Covishield', 2, 3, 0, 1),
(2, 'Covaxin', 3, 4, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vaccine_booked`
--

CREATE TABLE IF NOT EXISTS `vaccine_booked` (
  `v_b_id` int(11) NOT NULL,
  `u_name` varchar(15) NOT NULL,
  `v_name` varchar(15) NOT NULL,
  `v_c_name` varchar(50) NOT NULL,
  `v_b_date` date NOT NULL,
  `v_b_dose` date NOT NULL,
  `v_status` tinyint(1) NOT NULL,
  `dose_remain` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vaccine_booked`
--

INSERT INTO `vaccine_booked` (`v_b_id`, `u_name`, `v_name`, `v_c_name`, `v_b_date`, `v_b_dose`, `v_status`, `dose_remain`) VALUES
(0, 'Darshee', 'Covishield', 'Vikas Nursing Home', '2021-04-18', '2021-05-09', 1, 0),
(0, 'Darshee', 'Covaxin', 'Vikas Nursing Home', '2021-04-19', '2021-05-10', 0, 2);
