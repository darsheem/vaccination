<?php
	session_start();

	$con=mysqli_connect("localhost","root","","vaccination") or die('Mysql Connection Error'. mysqli_connect_error());

	$uname = $_SESSION['username'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>View User Vaccines</title>
	<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

  <style type="text/css">
  	.box{
  		margin-top: 10%;
  		text-align: center;
  		font-family: sans-serif;
  		margin-left: 30%;
  	}
  	table{
  		border-radius: 15px;
  		border: 0px;
  		padding: 10px;
  	}
  	.head{
  		background-color: #0A3E5C;
  		color: white;
  		border-radius: 15px;
  	}

  </style>
</head>
<body>

	<div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex align-items-center justify-content-center justify-content-md-between">
      <div class="align-items-center d-none d-md-flex">
        <i class="bi bi-clock"></i> Monday - Saturday, 8AM to 10PM
      </div>
      <div class="d-flex align-items-center">
        <i class="bi bi-phone"></i> Call us now +1 5589 55488 55
      </div>
    </div>
  </div>

  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto">E-Co Vaccine</a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
        	<li><a class="nav-link scrollto" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto " href="take_appointment.php">Take appointment</a></li>
          <li><a class="nav-link scrollto" href="view.php">View</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      
      <a href='userprofile.php' class='appointment-btn scrollto' target='_self'><?php echo $_SESSION['username']; ?></a>
      <a href='signout.php' class='appointment-btn scrollto' target='_self'>Sign out</a>
      
    </div>
  </header>



<div class="box">
  <table cellspacing="10" cellpadding="10">
  	
  	<tr class="head">
  		<th>Vaccine Name</th>
  		<th>Center Name</th>
  		<th>Start Date</th>
  		<th>Dose 1</th>
  		<th>Taken or Not?</th>
  	</tr>

  	<?php

  		$query = "SELECT * FROM vaccine_booked WHERE u_name = '$uname'";
  		$result = mysqli_query($con,$query);

  		while ($row = mysqli_fetch_array($result)) {

  	?>
  	<tr>
  		<td><?php echo $row['v_name']?></td>
  		<td><?php echo $row['v_c_name']?></td>
  		<td><?php echo $row['v_b_date']?></td>
  		<td><?php echo $row['v_b_dose']?></td>
  		<td><?php if ($row['v_status'] == 0)
  					  echo 'No'; 
  				  else 
  				  	echo 'Yes'; ?></td>
  	</tr>
  	
  	<?php
  		}
  	?>
  </table>
</div>
</body>
</html>